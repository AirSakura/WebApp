import request from "@/utils/request";
import { getToken } from "@/utils/auth";

// LSTM_CNN模型
export function xajDaily(data) {
  return request({
    url: "/xaj/calculate?token=" + getToken(),
    method: "post",
    data
  });
}