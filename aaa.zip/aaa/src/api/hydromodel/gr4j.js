import request from "@/utils/request";
import { getToken } from "@/utils/auth";

// GR4J模型
export function gr4jDaily(data) {
  return request({
    url: "/gr4j/calculate?token=" + getToken(),
    method: "post",
    data
  });
}



export function gr4jDataExport(data) {
  return request({
    url: "/gr4j/list/export?token=" + getToken(),
    method: "post",
    header: {
      "Content-Type": "application/json" //规定传递的参数格式为json
    },
    data
  });
}


export function gr4jCalib(data) {
  return request({
    url: "/gr4j/calibrate?token=" + getToken(),
    method: "post",
    data
  });
}

