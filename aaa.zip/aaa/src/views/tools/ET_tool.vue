<template>
  <div class="app-container" style="margin-top: 30px">
    <el-row :gutter="10" class="row-con">
      <el-col
        :span="6"
        v-for="(item, index) in list"
        :key="index"
        :offset="index > 0 ? 1 : 1"
        style="margin-bottom: 25px"
      >
        <el-card :body-style="{ padding: '0px' }" class="card">
          <div
            style="display: flex; align-items: center; padding: 10px 0 0 10px"
          >
            <img :src="item.url" class="image" />

            <span style="font-size: 1.3em; font-weight: 800">{{
              item.name
            }}</span>
          </div>
          <div style="padding: 14px">
            <div class="bottom clearfix">
              <el-button
                style="font-size: 1em; font-weight: 500; font-family: KaiTi"
                type="text"
                class="button"
                @click="handleLink(item)"
                >进入工具</el-button
              >
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <!-- <div>
      <span
        ><a href="https://baidu.com" target="_blank" rel="noopener noreferrer"
          >百度</a
        ></span
      >
    </div> -->
  </div>
</template>

<script>
import { getToken } from "@/utils/auth";
import store from "@/store";
import * as echarts from "echarts";
export default {
  name: "test",
  data() {
    return {
      list: [
        {
          name: "彭曼公式计算蒸发",
          url:
            "https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png",
          link: "/tools/tools/PM",
          status: 0
        },
        {
          name: "百度",
          url:
            "https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png",
          link: "https://baidu.com",
          status: 2
        },
        {
          name: "计算蒸发1",
          url:
            "https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png",
          link: "",
          status: 0
        },
        {
          name: "计算蒸发2",
          url:
            "https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png",
          link: "",
          status: 0
        },
        {
          name: "计算蒸发3",
          url:
            "https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png",
          link: "name:'datainput', params: { id: this.id }",
          status: 0
        }
      ]
    };
  },
  computed: {
    headers() {
      return {
        token: getToken()
      };
    }
  },
  mounted() {
    this.clientHeight = document.body.clientHeight - 205;

    window.onresize = () => {
      this.myChart && this.myChart.resize();
    };
  },
  methods: {
    handleLink(item) {
      console.log(item);
      if (item.status == 0) {
        this.$router.push({ path: item.link });
      } ////跳内部地址
      // location.href = "https://baidu.com";//跳外部地址
      console.log(item);
      if (item.status == 1) {
        window.open(`${location.origin}/#${item.link}`); ////新页面跳转
      }
      if (item.status == 2) {
        window.open(item.link); ////新页面跳转
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.time {
  font-size: 13px;
  color: #999;
}

.bottom {
  margin-top: 13px;
  line-height: 12px;
  //   width: 100px;
}

.button {
  padding: 0;
  float: right;
}

.image {
  width: 20%;
  margin-right: 10px;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}

.clearfix:after {
  clear: both;
}
.row-con {
  margin-bottom: 20px;
  display: flex;
  flex-wrap: wrap;
}
.row-con .card {
  min-width: 100%;
  height: 100%;
  margin-right: 20px;
  transition: all 0.5s;
}
</style>
