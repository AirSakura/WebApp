<template>
  <div style="width: 100%;height: auto;">
    <!-- 视频站点统计 -->
    <div class="container">
      <p class="title"><span class="block"></span>数据共享统计</p>
      <div class="video">
        <div class="count">
          <p class="number">{{ warnData.total2 }}</p>
          <p>离线站点</p>
        </div>
        <div class="count count1">
          <p class="number">{{ warnData.total1 }}</p>
          <p>站点总数</p>
        </div>
        <div class="pie">
          <!-- <el-progress
            type="circle"
            :percentage="Number(warnData.grade1 * 100).toFixed(0)"
            color=""
            define-back-color="#557AF2"
            color="#d95050"
          ></el-progress> -->

          <canvas id="pieBg" class="pos"></canvas>
          <canvas id="pieBar" class="pos"></canvas>

          <div class="pie-in">
            <p class="number">
              {{ Number(warnData.grade1 * 100).toFixed(0) }}%
            </p>
            <p>离线率</p>
          </div>
        </div>
      </div>
    </div>
    <!-- 视频监控列表 -->
    <div class="container">
      <p class="title"><span class="block"></span>数据共享列表</p>
      <div class="water-query rain-query">
        <div class="filter-container">
          <div class="filter-line">
            <div class="filter-item">
              <span>水库名称：</span>
              <el-input
                placeholder="请输入"
                v-model="listQuery.keywords"
                class="fillet fillet-input"
              >
              </el-input>
            </div>
            <div class="filter-item">
              <span>行政区划：</span>
              <HomeSelectPart
                class="fillet fillet-select"
                ref="selztree"
                v-model="listQuery.partid"
                :multiple="false"
                width="260"
              />
            </div>
          </div>
        </div>
        <el-button
          class="filter-btn"
          type="primary"
          icon="el-icon-search"
          @click="getList"
          >查询</el-button
        >

        <el-table
          :header-cell-style="{ background: '#eef1f6' }"
          :data="list"
          :min-height="160"
          :max-height="360"
          stripe
        >
          <el-table-column prop="partname" label="水库名称"> </el-table-column>
          <el-table-column prop="zonename" label="行政区划"> </el-table-column>
          <el-table-column prop="count" label="监控点数量">
            <template slot-scope="{ row }">
              {{ row.count }}个
            </template>
          </el-table-column>
          <el-table-column label="操作">
            <template slot-scope="{ row }">
              <el-button
                class="list-btn"
                type="primary"
                size="mini"
                @click="handleView(row)"
                >查看</el-button
              >
            </template>
          </el-table-column>
        </el-table>

        <pagination
          v-show="total > 0"
          :total="total"
          :page.sync="listQuery.page"
          :limit.sync="listQuery.limit"
          @pagination="getList"
        />
      </div>
    </div>
  </div>
</template>
<script>
import { partCamera } from "@/api/analysis";
import { listCamera } from "@/api/video";
import { getToken } from "@/utils/auth";
import { mapActions } from "vuex";

export default {
  name: "monitor",
  props: {
    warning: {
      default: () => ({}),
      type: Object
    }
  },
  data() {
    return {
      list: [], // 列表
      total: 0,
      listLoading: false,
      listQuery: {
        page: 1,
        limit: 10,
        keywords: ""
      },
      curPart: "",
      datetime: "",
      percent: [],
      warnData: {}
    };
  },
  computed: {
    headers() {
      return {
        token: getToken()
      };
    }
  },
  watch: {
    warning(n) {
      this.warnData = n;
      this.drawProgress(1, 108, "#557AF2", "pieBg");
      this.drawProgress(-n.grade1, 108, "#d95050", "pieBar");
    }
  },

  mounted() {
    this.getList();
  },
  methods: {
    ...mapActions(["setSiteType", "setSiteList"]),

    // 显示地图点位
    handleView(row) {
      listCamera({
        islimit: 0,
        partid: row.partid
      }).then(res => {
        this.setSiteType("monitor" + row.partid);
        this.setSiteList(res.data.data);
      });
    },
    //绘制圆弧进度条
    drawProgress(num, diameter, color, id) {
      let canvas = document.getElementById(id);
      if (canvas) {
        canvas.width = diameter;
        canvas.height = diameter;
        let ctx = canvas.getContext("2d");
        ctx.strokeStyle = color;
        ctx.lineWidth = 12;
        let r = diameter / 2;
        ctx.translate(r, r);
        ctx.beginPath();
        ctx.arc(0, 0, r - 12, 0, 2 * Math.PI * num, true);
        ctx.stroke();
      }
    },
    getList() {
      this.listLoading = true;
      partCamera(this.listQuery)
        .then(res => {
          this.list = res.data.data;
          this.total = res.data.total;
          this.listLoading = false;
        })
        .catch(res => {
          this.list = [];
          this.total = 0;
          this.listLoading = false;
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.container {
  background: #fff;
  width: 520px;
  border-radius: 8px;
  top: 0px;
  box-sizing: border-box;
  padding: 20px;
  margin: 0 0 20px 0;
  position: relative;
  color: #000;
  font-size: 14px;
  z-index: 999;

  .title {
    display: flex;
    align-items: center;
    font-size: 20px;
    font-weight: bold;
    height: 30px;
    margin: 0 0 13px 0;
    .block {
      width: 4px;
      height: 20px;
      border-radius: 2px;
      margin: 0 8px 0 0;
      background: linear-gradient(
        180deg,
        rgba(85, 122, 242, 1) 0%,
        rgba(73, 199, 201, 1) 100%
      );
    }
    .number {
      color: #d95050;
      margin: 0 0 0 8px;
    }
  }
  .progress {
    .item {
      width: 100%;
      height: 24px;
      margin: 16px 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      &:last-child {
        margin-bottom: 0;
      }
      .name {
        width: 64px;
      }
      .bar-bg {
        height: 24px;
        width: 75%;
        border-radius: 12px;
        background: #f2f4fa;
        margin: 0 1% 0 0;
        position: relative;
        .bar {
          height: 24px;
          width: 0;
          border-radius: 12px 0 0 12px;
          background: linear-gradient(
            -90deg,
            rgba(85, 122, 242, 1) 0%,
            rgba(73, 199, 201, 1) 100%
          );
          position: absolute;
          top: 0;
          left: 0;
        }
        .percent {
          height: 24px;
          display: flex;
          align-items: center;
          position: absolute;
          top: 0;
          left: 0;
        }
      }
      .number {
        width: 30px;
        color: #557af2;
        display: flex;
      }
    }
  }
  .spread-select {
    position: absolute;
    top: 18px;
    right: 20px;
  }
  // 覆写table
  /deep/.el-table--striped .el-table__body tr.el-table__row--striped td {
    background: rgba(242, 244, 250, 1);
  }
  /deep/.el-table td,
  .building-top .el-table th.is-leaf {
    border: none;
  }

  .pagination-container {
    padding: 16px 0 0;
  }
  // 测站建设
  .survey {
    padding: 2px 20px 18px;
    overflow: hidden;
    .station {
      width: 122px;
      height: 60px;
      float: left;
      margin: 16px 36px 0 0;
      display: flex;
      &:nth-child(3n) {
        margin-right: 0;
      }
      .img {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: #557af2;
        margin: 0 8px 0 0;
      }
      .info {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        .name {
          line-height: 21px;
        }
        .number {
          line-height: 35px;
          .num {
            font-size: 24px;
            font-weight: bold;
            color: #557af2;
          }
        }
      }
    }
  }
  // 水情预警
  .water-warn {
    .warn {
      padding: 16px 0 0;
      display: flex;
      justify-content: space-around;
      .left {
        display: flex;
        align-items: center;
        .img {
          width: 48px;
          height: 48px;
          border-radius: 24px;
          background: #f2f4fa;
          margin: 0 8px 0 0;
        }
        .img-small {
          width: 36px;
          height: 36px;
          border-radius: 18px;
          margin: 0 4px 0 0;
        }

        .info {
          display: flex;
          flex-direction: column;
          justify-content: center;
          .number {
            font-size: 18px;
            font-weight: bold;
            text-align: center;
          }
          .name {
            color: rgba(118, 119, 122, 1);
          }
        }
      }
    }
    // 雨情预警
    .rain {
      justify-content: space-between;
    }
    .quality {
      justify-content: flex-start;
      .left1 {
        margin: 0 0 0 68px;
      }
    }
  }
  .total {
    position: absolute;
    top: 24px;
    right: 20px;
    .number {
      color: #d95050;
      font-size: 20px;
      font-weight: bold;
      margin: 0 4px;
    }
  }
  // 覆写下拉选
  .fillet {
    width: 130px !important;
    /deep/.el-input__inner {
      width: 130px !important;
      height: 30px !important;
      border-radius: 15px !important;
      background: rgba(242, 244, 250, 1);
      border: none;
    }
    /deep/.el-select__caret {
      height: 30px !important;
      line-height: 30px !important;
    }
    /deep/.el-input__suffix {
      right: 12px !important;
    }
    /deep/ .vue-treeselect__control {
      width: 130px !important;
      height: 30px !important;
      line-height: 30px !important;
      border-radius: 15px !important;
      background: #f2f4fa;
      border: none;
    }
    /deep/ .vue-treeselect__single-value {
      height: 30px !important;
      line-height: 30px !important;
    }
  }
  .fillet-input {
    /deep/.el-input__inner {
      width: 180px !important;
    }
  }
  // 查询条件
  .filter-container {
    position: relative;
    overflow: hidden;
    .filter-line {
      display: flex;
      overflow: hidden;
      justify-content: space-between;
    }
    .filter-item {
      display: flex;
      align-items: center;
      float: left;
      margin: 0 0 16px 0;
    }

    .filter-time {
      .el-range-editor.el-input__inner {
        height: 30px !important;
        border-radius: 15px !important;
        background: rgba(242, 244, 250, 1);
        border: none;
      }
      /deep/.el-date-editor .el-range-input {
        background: rgba(242, 244, 250, 1) !important;
      }
      /deep/.el-date-editor .el-range__icon,
      /deep/.el-date-editor .el-range__close-icon,
      /deep/.el-date-editor .el-range-separator {
        height: 30px !important;
        line-height: 30px !important;
      }
    }
  }
  .filter-btn {
    width: 80px;
    height: 30px;
    background: linear-gradient(
      -90deg,
      rgba(85, 122, 242, 1) 0%,
      rgba(73, 199, 201, 1) 100%
    );
    border: none;
    border-radius: 15px;
    position: absolute;
    top: 20px;
    right: 20px;
  }
  .filter-btn-bottom {
    right: 0;
    top: 46px;
  }
  /deep/.el-button {
    padding: 0;
  }
  .rain-query {
    .rain-radio {
      margin-bottom: 8px;
    }
    .rain-station {
      overflow: hidden;
      margin: 0 0 16px 0;
      width: 100%;
      .station {
        width: 25%;
        float: left;
        margin: 16px 0 0;
        .top {
          margin-bottom: 4px;
        }
        .dot {
          width: 12px;
          height: 12px;
          border-radius: 6px;
          display: inline-block;
          background: #557af2;
          margin-right: 2px;
        }
      }
    }
  }
  .video {
    overflow: hidden;
    display: flex;
    align-items: center;
    .count {
      height: 48px;
      float: left;
      border-left: 2px solid #d95050;
      padding: 0 0 0 12px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      margin-left: 32px;
      .number {
        font-size: 20px;
        font-weight: bold;
        color: #d95050;
      }
    }
    .count1 {
      border-left: 2px solid #e9eaf0;
    }
    .pie {
      width: 110px;
      height: 110px;
      border-radius: 50%;
      border: 1px solid #e9eaf0;
      margin: 0 0 0 80px;
      position: relative;
      .pos {
        width: 108px;
        height: 108px;
        position: absolute;
        top: 0;
        left: 0;
        transform: rotate(-90deg);
      }
      .pie-in {
        width: 110px;
        height: 110px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        .number {
          font-size: 24px;
          font-weight: bold;
          color: #557af2;
          margin: 0 0 6px 0;
        }
      }
    }
  }
}
.list-btn {
  padding: 5px 10px !important;
  border-radius: 15px;
}
</style>
